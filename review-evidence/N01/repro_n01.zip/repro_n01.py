"""Run on P800/KL3 with the XPU build of FlagTree and its PyTorch runtime."""
import argparse
import hashlib
import json
import math
import random
import re
import statistics
import subprocess
from pathlib import Path

import torch
import triton
import triton.language as tl
import triton.experimental.tle.language as tle
from triton.backends import llvm19_toolchain
from triton.tools.tensor_descriptor import TensorDescriptor


@triton.jit
def two_exp(src, pos, neg, R: tl.constexpr, C: tl.constexpr):
    off = tl.program_id(0) * R
    buf = tle.gpu.alloc([R, C], dtype=tl.float32, scope=tle.gpu.lmem)
    rows = tl.broadcast_to(tl.arange(0, R)[:, None], (R, C))
    cols = tl.broadcast_to(tl.arange(0, C)[None, :], (R, C))
    ptr = tle.gpu.local_ptr(buf, (rows, cols))
    tle.gpu.copy(src, buf, [R, C], [off, 0])
    x = tl.load(ptr)
    a, b = tl.exp(x), tl.exp(-x)
    tl.store(ptr, a)
    tle.gpu.copy(buf, pos, [R, C], [off, 0])
    tl.store(ptr, b)
    tle.gpu.copy(buf, neg, [R, C], [off, 0])


@triton.jit
def ordered_max(a, b):
    return tl.where(a > b, a, b)


@triton.jit(do_not_specialize=["N"])
def add_softmax(src, bias, dst, N, R: tl.constexpr, C: tl.constexpr):
    off = tl.program_id(0) * R
    buf = tle.gpu.alloc([R, C], dtype=tl.float32, scope=tle.gpu.lmem)
    bb = tle.gpu.alloc([C], dtype=tl.float32, scope=tle.gpu.lmem)
    rows = tl.broadcast_to(tl.arange(0, R)[:, None], (R, C))
    col = tl.arange(0, C)
    ptr = tle.gpu.local_ptr(buf, (rows, tl.broadcast_to(col[None, :], (R, C))))
    bp = tle.gpu.local_ptr(bb, (col,))
    tle.gpu.copy(bias, bb, [C], [0])
    b = tl.load(bp)
    tle.gpu.copy(src, buf, [R, C], [off, 0])
    v = tl.load(ptr) + b[None, :]
    m = tl.reduce(v, 1, ordered_max)
    e = tl.exp(v - m[:, None])
    inv = tl.div_rn(1.0, tl.sum(e, 1))
    tl.store(ptr, e * inv[:, None])
    tle.gpu.copy(buf, dst, [R, C], [off, 0])


def instructions(kernel, symbol, out, stem):
    elf = out / (stem + ".elf")
    elf.write_bytes(bytes(kernel.asm["elf"]))
    tools = Path(llvm19_toolchain.get_llvm19_bin_dir("xpu"))
    env = llvm19_toolchain.llvm19_env("xpu")
    headers = subprocess.check_output([tools / "llvm-readelf", "-SW", elf], env=env, text=True)
    section = re.search(r"\.text\." + re.escape(symbol) + r"\s+PROGBITS\s+\w+\s+([\da-fA-F]+)\s+([\da-fA-F]+)", headers)
    if not section:
        raise RuntimeError(f"Missing kernel text section for {symbol} in {elf}")
    offset, size = (int(v, 16) for v in section.groups())
    raw = elf.read_bytes()[offset:offset + size]
    encoded = " ".join(f"0x{b:02x}" for b in raw)
    asm = subprocess.run([tools / "llvm-mc", "--disassemble", "--triple=xpu3-baidu-none-gnu", "--mcpu=xpu3"],
                         env=env, input=encoded, text=True, capture_output=True, check=True)
    if asm.stderr.strip() or len(raw) != size or size == 0:
        raise RuntimeError(f"Could not decode {symbol}: {asm.stderr}")
    (out / (stem + ".s")).write_text(asm.stdout)
    return {"bytes": size, "text_sha256": hashlib.sha256(raw).hexdigest(),
            "extract": len(re.findall(r"(?m)^\s*vextracti\.f\s", asm.stdout)),
            "exp": len(re.findall(r"(?m)^\s*exp\.f\.rn\s", asm.stdout))}


def time_device(fns):
    graphs, samples = {}, {name: [] for name in fns}
    for name, fn in fns.items():
        for _ in range(4):
            fn()
        torch.cuda.synchronize()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph, stream=torch.cuda.Stream()):
            for _ in range(8):
                result = fn()
        graphs[name] = (graph, result)
        graph.replay()
        torch.cuda.synchronize()
    rng = random.Random(943)
    for batch in range(36):
        names = list(fns)
        rng.shuffle(names)
        for name in names:
            start, stop = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
            start.record()
            graphs[name][0].replay()
            stop.record()
            stop.synchronize()
            if batch >= 5:
                samples[name].append(start.elapsed_time(stop) * 1000 / 8)
    for timings in samples.values():
        if not all(math.isfinite(t) and t > 0 for t in timings):
            raise RuntimeError("Invalid device-event timing")
    return {"median_us": {k: statistics.median(v) for k, v in samples.items()}, "samples_us": samples}


def main(args):
    target = triton.runtime.driver.active.get_current_target()
    if target.arch != 3 or target.warp_size != 1:
        raise SystemExit(f"Select a P800/KL3 device; found {target}")
    out = args.out
    out.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(1)
    torch.set_grad_enabled(False)
    torch.manual_seed(61)
    desc = TensorDescriptor.from_tensor
    report = {"target": str(target), "torch": str(torch.__version__), "two_exp": []}
    opts = {"num_warps": 8, "num_stages": 1}
    for r, c in [(8, 128), (16, 2048)]:
        x = torch.randn(3 * r, c, generator=torch.Generator().manual_seed(37)).cuda()
        a, b = torch.empty_like(x), torch.empty_like(x)
        ds = [desc(t, [r, c]) for t in (x, a, b)]
        k = two_exp[(3,)](*ds, r, c, **opts)
        for got, val in [(a, x), (b, -x)]:
            torch.testing.assert_close(got.cpu(), val.cpu().exp(), atol=1e-38, rtol=3e-6)
        report["two_exp"].append(instructions(k, "two_exp", out, f"exp-{r}x{c}"))

    x, b = torch.randn(2048, 2048).cuda(), torch.randn(2048).cuda()
    y = torch.empty_like(x)
    ds = [desc(x, [16, 2048]), desc(b, [2048]), desc(y, [16, 2048])]

    def fused():
        return add_softmax[(128,)](*ds, 2048, 16, 2048, **opts)

    def eager():
        return torch.softmax(x + b, -1)

    report["softmax"] = instructions(fused(), "add_softmax", out, "softmax")
    for label in ["random", "scaled", "nonfinite"]:
        if label == "scaled":
            x.mul_(16)
            b.mul_(0.5)
        if label == "nonfinite":
            x[0, 0], x[1, 1], x[2, :] = float("nan"), float("inf"), -float("inf")
        fused()
        torch.testing.assert_close(y.cpu(), eager().cpu(), atol=.0003, rtol=.0003, equal_nan=True)
    report["checks_passed"] = ["exp(x)", "exp(-x)", "softmax random", "softmax scaled", "softmax nonfinite"]
    x.copy_(torch.randn_like(x))
    b.copy_(torch.randn_like(b))
    report.update(time_device({"fused": fused, "eager": eager}))
    (out / "result.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "samples_us"}, indent=2))
    if args.expect:
        actual = [(r["extract"], r["exp"]) for r in report["two_exp"]]
        expected = [(32, 32), (1024, 1024)] if args.expect == "base" else [(0, 32), (0, 1024)]
        if actual != expected:
            raise SystemExit(f"Unexpected instruction counts for {args.expect}: {actual}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("n01-results"))
    parser.add_argument("--expect", choices=["base", "patched"], help="check counts for the reviewed versions")
    main(parser.parse_args())
